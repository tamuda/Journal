//
//  ComposeView.swift
//  Journal
//
//  Created by Tamuda Chimhanda on 10/23/23.
//

import SwiftUI

struct ComposeView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode

    @State private var title: String = ""
    @State private var text: String = ""

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Title")) {
                    TextEditor(text: $title)
                       
                    
                }
                Section(header: Text("Text")) {
                    TextEditor(text: $text)
                        .frame(height: 200)
                }
            }
            .navigationTitle("Compose Entry")
           
            .toolbar {
                ToolbarItem(placement: .bottomBar){
                    Button(action: {
                        addItem()
                        presentationMode.wrappedValue.dismiss()
                        
                    })
                    {
                        Text("Save")
                            .frame(maxWidth: .infinity)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                }
            }
        }
    }

    private func addItem() {
        withAnimation {
            let newItem = Item(context: viewContext)
            newItem.timestamp = Date()
            newItem.title = title
            newItem.text = text
            try? viewContext.save()
        }
    }
}

struct ComposeView_Previews: PreviewProvider {
    static var previews: some View {
        ComposeView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
