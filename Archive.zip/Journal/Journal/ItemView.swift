//
//  ItemView.swift
//  Journal
//
//  Created by Tamuda Chimhanda on 10/23/23.
//

import SwiftUI

struct ItemView: View {
    let item: Item
    var body: some View {
        VStack(alignment: .center){
            Text(item.title ?? "No Title")
                .font(.title)
                .padding(.bottom, 20)
            Text(item.text ?? "No entry")
                .font(.body)
            Text("Blood Pressure \(item.blood_pressure ?? 0)")
                .font(.body)
            Text("Weight: \(item.weight ?? 0)")
                .font(.body)
            Text(item.mood ?? "")
                .font(.body)
            Text(item.sleep_quality ?? "")
                .font(.body)
            Spacer()
            Text(item.timestamp?.description ?? "No date")
                .font(.caption)
                .foregroundColor(.secondary)
            
        }
        .padding()
        
    }
}

struct ItemView_Previews: PreviewProvider {
    static var previews: some View {
        let item = Item()
        return ItemView(item: item)
    }
}
