import SwiftUI

struct ComposeView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode

    @State private var title: String = ""
    @State private var text: String = ""
    @State private var mood: String = ""
    @State private var sleepQuality: String = ""
    @State private var bloodPressure: String = ""
    @State private var weight: String = ""

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Title")) {
                    TextEditor(text: $title)
                }
                Section(header: Text("Text")) {
                    TextEditor(text: $text)
                        .frame(height: 200)
                }
                Section(header: Text("Mood")) {
                    TextField("Mood", text: $mood)
                }
                Section(header: Text("Sleep Quality")) {
                    TextField("Sleep Quality", text: $sleepQuality)
                }
                Section(header: Text("Blood Pressure")) {
                    TextField("Blood Pressure", text: $bloodPressure)
                        .keyboardType(.decimalPad)
                }
                Section(header: Text("Weight")) {
                    TextField("Weight", text: $weight)
                        .keyboardType(.decimalPad)
                }
            }
            .navigationTitle("Compose Entry")
            .toolbar {
                ToolbarItem(placement: .bottomBar) {
                    Button(action: {
                        addItem()
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Text("Save")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                }
            }
        }
    }

    private func addItem() {
        withAnimation {
            let newItem = Item(context: viewContext)
            newItem.timestamp = Date()
            newItem.title = title
            newItem.text = text
            newItem.mood = mood
            newItem.sleep_quality = sleepQuality

            // Convert string input to Float for bloodPressure and weight
            newItem.blood_pressure = Float(bloodPressure) ?? 0
            newItem.weight = Float(weight) ?? 0

            try? viewContext.save()
        }
    }
}

struct ComposeView_Previews: PreviewProvider {
    static var previews: some View {
        ComposeView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
